#pragma once
#include <iostream>
#include <string>
#include <ctime>
#include "ArvoreBinaria.h"

using namespace std;

int main()
{
	setlocale(LC_ALL, "ptb");
	ArvoreBinaria<int> * ab = new ArvoreBinaria<int>;
	ab->inserir(10);
	ab->inserir(20);
	ab->inserir(5);
	ab->inserir(3);
	ab->inserir(7);
	cout << "Caminhamento Pr�-Fixado:\n";
	ab->visitarPreOrdem();
	cout << "\n///////////////////////////\nCaminhamento Central:\n";
	ab->visitarCentral();
	cout << "\n///////////////////////////\nCaminhamento P�s-Fixado:\n";
	ab->visitarPosOrdem();

	system("pause");
	return 0;
}
